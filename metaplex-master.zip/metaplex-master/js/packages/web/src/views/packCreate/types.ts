export enum CreatePackSteps {
  SelectItems,
  SelectVoucher,
  AdjustQuantities,
  // SalesSettings,
  // DesignAndInfo,
  ReviewAndMint,
}

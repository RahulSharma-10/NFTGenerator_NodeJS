import { TokenInfo } from '@solana/spl-token-registry';

export const filterModalSolTokens = (tokens: TokenInfo[]) => {
  return tokens;
};
declare module 'jazzicon' {
  const jazzicon: any;
  export = jazzicon;
}

export const MAX_PACK_SET_SIZE = 853;

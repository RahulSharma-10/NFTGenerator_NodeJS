---
title: Auction Program
---

## Background

Solana's programming model and the definitions of the Solana terms used in this
document are available at:

- https://docs.solana.com/apps
- https://docs.solana.com/terminology

## Source

The Auction Program's source is available on
[github](https://github.com/metaplex-foundation/metaplex)

## Interface

TODO

## Operational Overview

TODO
